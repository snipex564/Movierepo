import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity, SafeAreaView } from 'react-native';
import { WebView } from 'react-native-webview';
import { StreamSource } from '../services/streamProvider';
import { Colors } from '../constants/theme';

interface StreamPlayerProps {
  source: StreamSource;
  onClose: () => void;
}

export const StreamPlayer: React.FC<StreamPlayerProps> = ({ source, onClose }) => {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.closeButton} onPress={onClose}>
          <Text style={styles.closeText}>✕ Close Player</Text>
        </TouchableOpacity>
        <Text style={styles.title} numberOfLines={1}>{source.title}</Text>
      </View>

      {source.isTorrent ? (
        <View style={styles.torrentNotice}>
          <Text style={styles.torrentHeader}>Torrent Stream Selected</Text>
          <Text style={styles.torrentTitle}>{source.title}</Text>
          <Text style={styles.details}>Quality: {source.quality} | Size: {source.size || 'N/A'}</Text>
          <Text style={styles.details}>Seeds: {source.seeds} | Peers: {source.peers}</Text>
          <Text style={styles.hint}>
            Magnet link resolved! Direct torrent streaming requires local WebTorrent client playback.
          </Text>
        </View>
      ) : (
        <WebView
          source={{ uri: source.url }}
          style={styles.webview}
          allowsFullscreenVideo
          javaScriptEnabled
          domStorageEnabled
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: Colors.surface,
  },
  closeButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: Colors.primary,
    borderRadius: 4,
    marginRight: 10,
  },
  closeText: { color: '#FFF', fontWeight: 'bold', fontSize: 12 },
  title: { color: '#FFF', fontSize: 14, fontWeight: '600', flex: 1 },
  webview: { flex: 1 },
  torrentNotice: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  torrentHeader: { color: Colors.green, fontSize: 18, fontWeight: 'bold' },
  torrentTitle: { color: '#FFF', fontSize: 16, marginVertical: 8, textAlign: 'center' },
  details: { color: Colors.textSecondary, fontSize: 14, marginBottom: 4 },
  hint: { color: '#888', fontSize: 12, textAlign: 'center', marginTop: 16 }
});