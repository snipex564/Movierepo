import React from 'react';
import { Modal, StyleSheet, View, Text, TouchableOpacity, FlatList } from 'react-native';
import { StreamSource } from '../services/streamProvider';
import { Colors } from '../constants/theme';

interface Props {
  visible: boolean;
  sources: StreamSource[];
  onSelect: (source: StreamSource) => void;
  onClose: () => void;
}

export const StreamSelectorModal: React.FC<Props> = ({ visible, sources, onSelect, onClose }) => {
  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.content}>
          <Text style={styles.header}>Available Scraped Streams</Text>
          <FlatList
            data={sources}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <TouchableOpacity style={styles.sourceCard} onPress={() => onSelect(item)}>
                <View style={styles.row}>
                  <Text style={styles.badge}>{item.quality}</Text>
                  <Text style={styles.provider}>{item.provider}</Text>
                </View>
                <Text style={styles.sourceTitle}>{item.title}</Text>
                {item.isTorrent && (
                  <Text style={styles.meta}>Seeds: {item.seeds} | Peers: {item.peers} | Size: {item.size}</Text>
                )}
              </TouchableOpacity>
            )}
          />
          <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
            <Text style={styles.cancelText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.85)', justifyContent: 'flex-end' },
  content: { backgroundColor: Colors.surface, borderTopLeftRadius: 16, borderTopRightRadius: 16, padding: 16, maxHeight: '70%' },
  header: { color: '#FFF', fontSize: 18, fontWeight: 'bold', marginBottom: 16 },
  sourceCard: { backgroundColor: '#2A2A2A', padding: 12, borderRadius: 8, marginBottom: 10 },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  badge: { backgroundColor: Colors.primary, color: '#FFF', fontSize: 10, fontWeight: 'bold', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4, marginRight: 8 },
  provider: { color: Colors.textSecondary, fontSize: 12 },
  sourceTitle: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  meta: { color: Colors.green, fontSize: 11, marginTop: 4 },
  cancelButton: { padding: 14, alignItems: 'center', marginTop: 10 },
  cancelText: { color: Colors.primary, fontWeight: 'bold' }
});