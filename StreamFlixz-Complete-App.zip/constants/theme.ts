export const Colors = {
  background: '#141414',
  surface: '#1F1F1F',
  primary: '#E50914',
  textPrimary: '#FFFFFF',
  textSecondary: '#AAAAAA',
  border: '#333333',
  green: '#46D369'
};