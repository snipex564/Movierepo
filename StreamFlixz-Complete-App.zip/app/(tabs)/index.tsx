import React from 'react';
import { StyleSheet, View, Text, Image, ScrollView, TouchableOpacity, SafeAreaView, StatusBar } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '../../constants/theme';

const MOCK_MOVIES = [
  { id: 'tt1375666', title: 'Inception', poster: 'https://image.tmdb.org/t/p/w500/edv5CZvWj09upO2S2Z1M3GrmL3U.jpg' },
  { id: 'tt0816692', title: 'Interstellar', poster: 'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg' },
  { id: 'tt0468569', title: 'The Dark Knight', poster: 'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg' },
  { id: 'tt1877830', title: 'The Batman', poster: 'https://image.tmdb.org/t/p/w500/74xTEgt7R36Fpooo50r9221SpR9.jpg' },
];

export default function HomeScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.logo}>STREAMFLIXZ</Text>
        </View>

        <View style={styles.heroContainer}>
          <Image source={{ uri: MOCK_MOVIES[0].poster }} style={styles.heroImage} />
          <View style={styles.heroOverlay}>
            <Text style={styles.heroTitle}>{MOCK_MOVIES[0].title}</Text>
            <TouchableOpacity 
              style={styles.playButton}
              onPress={() => router.push(`/title/${MOCK_MOVIES[0].id}` as any)}
            >
              <Text style={styles.playText}>▶ Play</Text>
            </TouchableOpacity>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Trending Movies</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.row}>
          {MOCK_MOVIES.map((movie) => (
            <TouchableOpacity 
              key={movie.id} 
              style={styles.posterCard}
              onPress={() => router.push(`/title/${movie.id}` as any)}
            >
              <Image source={{ uri: movie.poster }} style={styles.posterImage} />
            </TouchableOpacity>
          ))}
        </ScrollView>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: { padding: 16, backgroundColor: 'transparent' },
  logo: { color: Colors.primary, fontSize: 24, fontWeight: '900', letterSpacing: 1 },
  heroContainer: { height: 400, position: 'relative', marginBottom: 20 },
  heroImage: { width: '100%', height: '100%' },
  heroOverlay: { position: 'absolute', bottom: 20, left: 16, right: 16 },
  heroTitle: { color: '#FFF', fontSize: 28, fontWeight: 'bold', marginBottom: 12 },
  playButton: { backgroundColor: '#FFF', paddingVertical: 10, borderRadius: 4, alignItems: 'center' },
  playText: { color: '#000', fontSize: 16, fontWeight: 'bold' },
  sectionTitle: { color: '#FFF', fontSize: 18, fontWeight: 'bold', marginLeft: 16, marginBottom: 10 },
  row: { paddingLeft: 16, marginBottom: 20 },
  posterCard: { marginRight: 12, width: 120, height: 180, borderRadius: 6, overflow: 'hidden' },
  posterImage: { width: '100%', height: '100%' }
});