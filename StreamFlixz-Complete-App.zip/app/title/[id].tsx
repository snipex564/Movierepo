import React, { useState } from 'react';
import { StyleSheet, View, Text, Image, TouchableOpacity, ActivityIndicator, SafeAreaView } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { fetchStreamSources, StreamSource } from '../../services/streamProvider';
import { StreamSelectorModal } from '../../components/StreamSelectorModal';
import { StreamPlayer } from '../../components/StreamPlayer';
import { Colors } from '../../constants/theme';

export default function TitleDetailScreen() {
  const { id } = useLocalSearchParams();
  const imdbId = Array.isArray(id) ? id[0] : id || 'tt1375666';

  const [loading, setLoading] = useState(false);
  const [sources, setSources] = useState<StreamSource[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [activeSource, setActiveSource] = useState<StreamSource | null>(null);

  const handleFetchStreams = async () => {
    setLoading(true);
    const result = await fetchStreamSources(imdbId, 'Selected Movie', 'movie');
    setSources(result);
    setLoading(false);
    setModalVisible(true);
  };

  if (activeSource) {
    return <StreamPlayer source={activeSource} onClose={() => setActiveSource(null)} />;
  }

  return (
    <SafeAreaView style={styles.container}>
      <Image 
        source={{ uri: 'https://image.tmdb.org/t/p/w500/edv5CZvWj09upO2S2Z1M3GrmL3U.jpg' }} 
        style={styles.backdrop} 
      />
      <View style={styles.details}>
        <Text style={styles.title}>Movie Details ({imdbId})</Text>
        <Text style={styles.description}>
          Scrapes and resolves direct stream links and torrent magnets for streaming on demand.
        </Text>

        <TouchableOpacity style={styles.playButton} onPress={handleFetchStreams} disabled={loading}>
          {loading ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <Text style={styles.playText}>Scrape & Play Streams</Text>
          )}
        </TouchableOpacity>
      </View>

      <StreamSelectorModal
        visible={modalVisible}
        sources={sources}
        onSelect={(source) => {
          setModalVisible(false);
          setActiveSource(source);
        }}
        onClose={() => setModalVisible(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  backdrop: { width: '100%', height: 260 },
  details: { padding: 16 },
  title: { color: '#FFF', fontSize: 24, fontWeight: 'bold', marginBottom: 8 },
  description: { color: Colors.textSecondary, fontSize: 14, lineHeight: 20, marginBottom: 20 },
  playButton: { backgroundColor: Colors.primary, paddingVertical: 14, borderRadius: 6, alignItems: 'center' },
  playText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' }
});