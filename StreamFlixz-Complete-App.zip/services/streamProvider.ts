export interface StreamSource {
  id: string;
  title: string;
  quality: '720p' | '1080p' | '4K' | 'SD';
  url: string;
  seeds?: number;
  peers?: number;
  size?: string;
  provider: string;
  isTorrent: boolean;
}

export async function fetchStreamSources(
  imdbId: string,
  title: string,
  type: 'movie' | 'series' = 'movie',
  season?: number,
  episode?: number
): Promise<StreamSource[]> {
  const sources: StreamSource[] = [];

  try {
    if (type === 'movie' && imdbId) {
      const ytsRes = await fetch(`https://yts.mx/api/v2/list_movies.json?query_term=${imdbId}`);
      const ytsData = await ytsRes.json();

      if (ytsData?.data?.movies?.[0]?.torrents) {
        ytsData.data.movies[0].torrents.forEach((t: any, index: number) => {
          sources.push({
            id: `yts-${index}`,
            title: `${title} (${t.quality})`,
            quality: t.quality as any,
            url: t.url,
            seeds: t.seeds,
            peers: t.peers,
            size: t.size,
            provider: 'YTS Torrent',
            isTorrent: true,
          });
        });
      }
    }

    const embedUrl = type === 'movie' 
      ? `https://vidsrc.me/embed/movie?imdb=${imdbId}`
      : `https://vidsrc.me/embed/tv?imdb=${imdbId}&season=${season || 1}&episode=${episode || 1}`;

    sources.push({
      id: 'vidsrc-direct',
      title: `${title} - Direct HD Stream`,
      quality: '1080p',
      url: embedUrl,
      provider: 'VidSrc Direct Stream',
      isTorrent: false,
    });

  } catch (error) {
    console.error("Error scraping sources:", error);
  }

  return sources;
}